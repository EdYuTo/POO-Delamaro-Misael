
public class Agenda {
	private Pessoa[] contatos;
	int atual;
	
	public Agenda (int ncontatos) {
		contatos = new Pessoa[ncontatos];
		atual = 0;
	}
	
	public void visualizarContatos() {
		for (int i = 0; i < atual; i++) {
			if (contatos[i] instanceof PessoaFisica)
				System.out.println(((PessoaFisica)contatos[i]).toString());
			else if (contatos[i] instanceof PessoaJuridica)
				System.out.println(((PessoaJuridica)contatos[i]).toString());
			else
				System.out.println(contatos[i].toString());
		}
	}
	
	private PessoaFisica criarPessoaFisica() throws Exception {
		String estado, data, nome, cpf, endereco, email;
		System.out.println("Digite o nome da pessoa:\n");
		nome = EntradaTeclado.leString();
		System.out.println("Digite o estado civil da pessoa:\n");
		estado = EntradaTeclado.leString();
		System.out.println("Digite a data de nascimento:\n");
		data = EntradaTeclado.leString();
		System.out.println("Digite o cpf:\n");
		cpf = EntradaTeclado.leString();
		System.out.println("Digite o endereco:\n");
		endereco = EntradaTeclado.leString();
		System.out.println("Digite o email:\n");
		email = EntradaTeclado.leString();
		PessoaFisica pessoa = new PessoaFisica(estado, data, nome, cpf, endereco, email);
		return pessoa;
	}
	
	private PessoaJuridica criarPessoaJuridica() throws Exception {
		String estadual, social, nome, cnpj, endereco, email;
		System.out.println("Digite o nome da pessoa juridica:\n");
		nome = EntradaTeclado.leString();
		System.out.println("Digite a inscricao estadual da pessoa juridica:\n");
		estadual = EntradaTeclado.leString();
		System.out.println("Digite a razao social:\n");
		social = EntradaTeclado.leString();
		System.out.println("Digite o cnpj:\n");
		cnpj = EntradaTeclado.leString();
		System.out.println("Digite o endereco:\n");
		endereco = EntradaTeclado.leString();
		System.out.println("Digite o email:\n");
		email = EntradaTeclado.leString();
		PessoaJuridica pessoa = new PessoaJuridica(estadual, social, nome, cnpj, endereco, email);
		return pessoa;
	}
	
	public boolean addContato(String tipo) {
		tipo.toLowerCase();
		try {
			if (tipo.equals("fisica")) {
				contatos[atual++] = criarPessoaFisica();
				return true;
			}
			else if (tipo.equals("juridica")) {
				contatos[atual++] = criarPessoaJuridica();
				return true;
			}  
		} catch (Exception e) {
				return false;
		}
		return false;
	}
	
	public boolean removeContato(String cpfcnpj) {
		int i;
		for (i = 0; i < atual && !cpfcnpj.equals(contatos[i].getCpfcnpj()); i++);//para no contato a ser removido
		if (i != atual) {
			while (i+1 != atual) {
				contatos[i] = contatos[i+1];
				i++;
			}
			atual--;
			contatos[atual] =  null;
			return true;
		} else
			return false;		
	}
}
